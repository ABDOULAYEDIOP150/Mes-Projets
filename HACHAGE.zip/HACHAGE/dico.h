#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef char chaine[30];
typedef struct dico
{
	chaine mot;
	struct dico *suiv;
}Dico;
typedef Dico *MonDico;
MonDico creer(chaine);
MonDico ajouterqueue(MonDico ,chaine );
void affiche(MonDico );
int hachage(chaine );
MonDico inserer1(char* , int);
int recherche(chaine );