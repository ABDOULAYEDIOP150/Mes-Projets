#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include "dico.h"
int main()
{
	
	 int i;
	i=recherche("livre");
	//i=recherche("layediop");
	printf("%d ",i);

	return 0;
}
