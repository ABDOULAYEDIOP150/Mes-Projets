#include "dico.h"
MonDico creer(chaine ch)
{
     MonDico elt;
     elt=(MonDico)malloc(sizeof(Dico));
     if(elt==NULL)
         return NULL;
     elt->suiv=NULL;
     strcpy(elt->mot,ch);
      return elt;
}
void affiche(MonDico liste)
{
   while(liste!=NULL)
    {
        printf("%s  ",liste->mot);
        liste=liste->suiv;
    }
}
MonDico ajoutertete(MonDico liste,chaine elt)
{
    MonDico maillon;
    maillon=creer(elt);
    if (liste==NULL)
    {
        liste=maillon;
    }
    else
    {
          maillon->suiv=liste;
          liste=maillon;
    }
  
    return liste;
}
MonDico ajouterqueue(MonDico liste,chaine elt){

     MonDico maillon,courant;
    maillon=creer(elt);
    courant=liste;
    if (liste==NULL)
    {
        liste=maillon;
    }
    else{
        while(courant->suiv!=NULL)
        {
            courant=courant->suiv;
        }
        courant->suiv=maillon;
        maillon=courant;
    }
    return  liste;

}
int hachage(chaine chaines)
 {
     int i = 0, nombreHache = 0;
     for (i = 0 ; chaines[i] != '\0' ; i++)
     {
         nombreHache += chaines[i];
     }
     nombreHache %= 150;
     return nombreHache;
 }
MonDico inserer1(char* ch,int l)
{
    FILE *f1;chaine ch1; 
    MonDico liste=(MonDico)malloc(sizeof(Dico)*150);
    if (liste==NULL)
        return NULL;
    f1=fopen(ch,"r");

    if(f1==NULL)
      {
        printf("Erreur d ouver\n");
        return NULL;
      }   
     while(!feof(f1))
             { 
                fscanf(f1,"%s",ch1);
                if(l==hachage(ch1))
                {
                    if (liste==NULL)
                       liste=creer(ch1);
                    else
                       liste=ajouterqueue(liste,ch1);
  
                }

             }
    return liste;
      fclose(f1);
}
int recherche(chaine ch)
{
    MonDico liste; int i;
    i=hachage(ch);
    liste=(MonDico)malloc(150*(sizeof(Dico)));
    if (liste==NULL)
        return -1;
    liste=inserer1("fichier1.txt",i);
    printf("<VOICI CI DESSOUS LES MOTS QUI ONT LE MEME HACHAGE QUE '%s' >",ch);
    printf("\n");
    printf("\n");
    affiche(liste);/*celle ligne me permet d'afficher les mot qui ont le meme hachage que le mot recherché*/
    printf("\n");
    printf("\n");
    while((liste!=NULL)&&(strcmp(liste->mot,ch)!=0))
        { 
            liste=liste->suiv;       

        }

        if(liste==NULL)
        {
           printf(" le mot <%s> n 'existe pas dans le dictionnaire ",ch );
           printf("\n");
           printf("\n");
           /*la fonction va retourner pour dire que le mot n'existe pas dans le dico*/
            return 0;
             
        }
          printf(" le mot <%s> existe dans le dictionnaire  ",ch );
          /*  la fonction retourne la valeur 1 pour dire que le mot existe dans le dico*/
          printf("\n");
          printf("\n");
         return 1;
}